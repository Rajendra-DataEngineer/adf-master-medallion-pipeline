source(output(
		SaleID as integer,
		CustomerID as integer,
		Amount as double,
		SaleDate as date,
		IngestionDate as date
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false,
	format: 'delta',
	fileSystem: 'silver',
	folderPath: 'sales_transformed') ~> silvercustomers
source(output(
		saleID as short,
		Product as string,
		amount as integer,
		saledate as date
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> silversales
silversales aggregate(groupBy(Product),
	totalsales = sum(amount)) ~> aggregate1
aggregate1 sink(allowSchemaDrift: true,
	validateSchema: false,
	format: 'parquet',
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> sink1