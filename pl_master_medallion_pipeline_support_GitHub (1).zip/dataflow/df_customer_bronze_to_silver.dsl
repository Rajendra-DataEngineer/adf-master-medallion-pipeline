source(output(
		CustomerID as string,
		CustomerName as string,
		Country as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> BronzeCustomers
BronzeCustomers derive(loaddate = currentTimestamp()) ~> SilverCustomersSink
SilverCustomersSink sink(allowSchemaDrift: true,
	validateSchema: false,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> WriteToSilverContainer